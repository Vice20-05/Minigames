package minigames;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;

// Loads and stores all the pictures. If a picture cannot be loaded
// its getter returns null and the GamePanel draws a simple shape instead.
public class GameImages {

    // Put your backgrounds in src/main/resources/images with these names.
    private static final String[] BACKGROUND_PATHS = {
        "/images/bg1.png",
        "/images/bg2.png",
        "/images/bg3.png",
        "/images/bg4.png",
        "/images/bg5.png"
    };

    // volatile: the loader thread writes them, the Swing thread reads them.
    private volatile Image currentBackgroundImage;
    private volatile Image playerOneTankImage;
    private volatile Image playerTwoTankImage;
    private volatile Image brickWallImage;
    private volatile Image steelWallImage;
    private volatile Image bulletImage;
    private volatile Image heartImage;

    private volatile Image[] backgroundImages;

    private final Random random;

    public GameImages() {
        random = new Random();
        backgroundImages = new Image[BACKGROUND_PATHS.length];
    }

    // Loads the PNG pictures from src/main/resources/images.
    // This is called by the image loader thread.
    public void loadAll() {
        playerOneTankImage = loadImage("/images/tank_blue.png");
        playerTwoTankImage = loadImage("/images/tank_bigRed.png");
        brickWallImage = loadImage("/images/barrelGreen_side.png");
        steelWallImage = loadImage("/images/barrelRust_side.png");
        bulletImage = loadImage("/images/bulletDark1_outline.png");
        heartImage = loadImage("/images/explosion2.png");

        Image[] loadedBackgrounds = new Image[BACKGROUND_PATHS.length];

        for (int backgroundNumber = 0;
                backgroundNumber < BACKGROUND_PATHS.length;
                backgroundNumber++) {

            loadedBackgrounds[backgroundNumber]
                    = loadImage(BACKGROUND_PATHS[backgroundNumber]);
        }

        backgroundImages = loadedBackgrounds;
        pickRandomBackground();
    }

    // Chooses one of the backgrounds that were really loaded.
    public void pickRandomBackground() {
        Image[] loadedBackgrounds = backgroundImages;
        ArrayList<Image> usableBackgrounds = new ArrayList<Image>();

        for (Image background : loadedBackgrounds) {
            if (background != null) {
                usableBackgrounds.add(background);
            }
        }

        if (usableBackgrounds.isEmpty()) {
            currentBackgroundImage = null;
            return;
        }

        int randomIndex = random.nextInt(usableBackgrounds.size());
        currentBackgroundImage = usableBackgrounds.get(randomIndex);
    }

    // Returns null when the picture is missing or broken.
    private Image loadImage(String imagePath) {
        try {
            URL imageURL = getClass().getResource(imagePath);

            if (imageURL == null) {
                System.out.println("Image not found: " + imagePath);
                return null;
            }

            BufferedImage loadedImage = ImageIO.read(imageURL);

            if (loadedImage == null) {
                System.out.println("Unsupported image format: " + imagePath);
            }

            return loadedImage;
        } catch (IOException exception) {
            System.out.println("Could not read image " + imagePath
                    + ": " + exception.getMessage());
            return null;
        } catch (IllegalArgumentException exception) {
            System.out.println("Bad image path " + imagePath
                    + ": " + exception.getMessage());
            return null;
        }
    }

    public Image getCurrentBackgroundImage() {
        return currentBackgroundImage;
    }

    public Image getPlayerOneTankImage() {
        return playerOneTankImage;
    }

    public Image getPlayerTwoTankImage() {
        return playerTwoTankImage;
    }

    public Image getBrickWallImage() {
        return brickWallImage;
    }

    public Image getSteelWallImage() {
        return steelWallImage;
    }

    public Image getBulletImage() {
        return bulletImage;
    }

    public Image getHeartImage() {
        return heartImage;
    }
}
